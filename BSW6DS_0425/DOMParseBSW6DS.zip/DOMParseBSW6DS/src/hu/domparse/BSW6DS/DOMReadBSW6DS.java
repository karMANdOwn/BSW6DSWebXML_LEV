package hu.domparse.BSW6DS;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/*
 DOMReadBSW6DS osztály
 Ez az osztály egy könyvtári rendszer amely XML dokumentumából olvas ki adatokat
 a DOM API használatával, és konzolra írja és fájlba menti az eredményt.
 */
public class DOMReadBSW6DS {

    /*
     A program belépési pontja.
     */
    public static void main(String[] args) {
        //fájl irásához kimenet
        PrintWriter outputFile = null;

        try {
            //fjl kimenet előkészítése
            outputFile = new PrintWriter(new FileWriter("XMLBSW6DS_output.txt"));

            //XML beolvasása
            File xmlFile = new File("XMLBSW6DS.xml");

            //XSD beolvasása
            File xsdFile = new File("XMLSchemaBSW6DS.xsd");

            //validációhoz Schema factory létrehozása
            SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
            Schema schema = schemaFactory.newSchema(xsdFile);

            //document builder factory létrehozása
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

            //validáció bekapcsolása
            factory.setValidating(false); // XSD validációnál ez false
            factory.setNamespaceAware(true);
            factory.setSchema(schema);

            //socument builder létrehozása
            DocumentBuilder builder = factory.newDocumentBuilder();

            //XML fájl betöltése és DOM létrehozása
            Document document = builder.parse(xmlFile);

            //a DOM fa tisztítása (üres szövegek, stb.),magyarul normaizálása
            document.getDocumentElement().normalize();

            //gyökérelem kiiratás
            String rootMessage = "Gyökér elem: " + document.getDocumentElement().getNodeName();
            System.out.println(rootMessage);
            outputFile.println(rootMessage);

            //deák adatok beolvasása kiiratása
            System.out.println("\n----- DIÁKOK ADATAI -----");
            outputFile.println("\n----- DIÁKOK ADATAI -----");
            readAndPrintDiakData(document, outputFile);

            //kategória adatok beolvasása kiiratása
            System.out.println("\n----- KATEGÓRIÁK ADATAI -----");
            outputFile.println("\n----- KATEGÓRIÁK ADATAI -----");
            readAndPrintKategoriaData(document, outputFile);

            //könyv adatok beolvasása kiiratása
            System.out.println("\n----- KÖNYVEK ADATAI -----");
            outputFile.println("\n----- KÖNYVEK ADATAI -----");
            readAndPrintKonyvData(document, outputFile);

            //részleg adatok beolvasása kiiratása
            System.out.println("\n----- RÉSZLEGEK ADATAI -----");
            outputFile.println("\n----- RÉSZLEGEK ADATAI -----");
            readAndPrintReszlegData(document, outputFile);

            //könyvtáros adatok beolvasása kiiratása
            System.out.println("\n----- KÖNYVTÁROSOK ADATAI -----");
            outputFile.println("\n----- KÖNYVTÁROSOK ADATAI -----");
            readAndPrintKonyvtarosData(document, outputFile);

            //kölcsönzés adatok beolvasása kiiratása
            System.out.println("\n----- KÖLCSÖNZÉSEK ADATAI -----");
            outputFile.println("\n----- KÖLCSÖNZÉSEK ADATAI -----");
            readAndPrintKolcsonzesData(document, outputFile);

            //értesités a sikerességről
            System.out.println("\nAz XML fájl feldolgozása sikeresen megtörtént!");
            outputFile.println("\nAz XML fájl feldolgozása sikeresen megtörtént!");

        //ha probléma van a DOM parser konfigurációjával ezt irja ki
        } catch (ParserConfigurationException e) {
            System.err.println("Parser konfigurációs hiba: " + e.getMessage());
            e.printStackTrace();

        //ha az XML elemzés folyamata közben van hiba ezt irja ki
        } catch (SAXException e) {
            System.err.println("SAX parsing hiba: " + e.getMessage());
            e.printStackTrace();

        //ha fájlműveletekkel kapcsolatos hiba történik ezt irja ki
        } catch (IOException e) {
            System.err.println("IO hiba: " + e.getMessage());
            e.printStackTrace();

        //ha van hiba ha nincs ez mindenképp lefut
        } finally {

            //fájl bezárás
            if (outputFile != null) {
                outputFile.close();
            }
        }
    }

    /*
     ez a metódus kiolvassa és kiírja a diákok adatait a dokumentumból.
     */
    private static void readAndPrintDiakData(Document document, PrintWriter writer) {
        //diák elemek lekérdezése
        NodeList diakList = document.getElementsByTagName("diak");

        //információ a találatok számáról
        String countInfo = "Összesen " + diakList.getLength() + " diák található.";
        System.out.println(countInfo);
        writer.println(countInfo);

        //végigmegyünk minden diák elemen
        for (int i = 0; i < diakList.getLength(); i++) {
            Node diakNode = diakList.item(i);

            // Ellenőrizzük, hogy elem típusú-e a csomópont (node)
            if (diakNode.getNodeType() == Node.ELEMENT_NODE) {
                Element diakElement = (Element) diakNode;

                //diák ID attribútum
                String id = diakElement.getAttribute("id");

                //adatok kinyerése az elemekből
                String nev = getElementTextContent(diakElement, "nev");
                String email = getElementTextContent(diakElement, "email");
                String osztaly = getElementTextContent(diakElement, "osztaly");
                String szuletesiDatum = getElementTextContent(diakElement, "szuletesiDatum");

                //adatok kiírása
                System.out.println("\nDiák [" + (i+1) + "]:");
                System.out.println("  ID: " + id);
                System.out.println("  Név: " + nev);
                System.out.println("  Email: " + email);
                System.out.println("  Osztály: " + osztaly);
                System.out.println("  Születési dátum: " + szuletesiDatum);

                //adatok fájlba irása
                writer.println("\nDiák [" + (i+1) + "]:");
                writer.println("  ID: " + id);
                writer.println("  Név: " + nev);
                writer.println("  Email: " + email);
                writer.println("  Osztály: " + osztaly);
                writer.println("  Születési dátum: " + szuletesiDatum);
            }
        }
    }

    /*
    ez a metódus kiolvassa és kiírja a kategóriák adatait a dokumentumból.
     */
    private static void readAndPrintKategoriaData(Document document, PrintWriter writer) {
        //kategória elemek lekérdezése
        NodeList kategoriaList = document.getElementsByTagName("kategoria");

        //információ a találatok számáról
        String countInfo = "Összesen " + kategoriaList.getLength() + " kategória található.";
        System.out.println(countInfo);
        writer.println(countInfo);

        //végigmegyünk minden kategória elemen
        for (int i = 0; i < kategoriaList.getLength(); i++) {
            Node kategoriaNode = kategoriaList.item(i);

            //ellenőrizzük, hogy elem típusú-e a csomópont (node)
            if (kategoriaNode.getNodeType() == Node.ELEMENT_NODE) {
                Element kategoriaElement = (Element) kategoriaNode;

                //kategória ID attribútum
                String id = kategoriaElement.getAttribute("id");

                //adatok kinyerése az elemekből
                String megnevezes = getElementTextContent(kategoriaElement, "megnevezes");
                String leiras = getElementTextContent(kategoriaElement, "leiras");

                //adatok kiírása
                System.out.println("\nKategória [" + (i+1) + "]:");
                System.out.println("  ID: " + id);
                System.out.println("  Megnevezés: " + megnevezes);
                System.out.println("  Leírás: " + leiras);

                //adatok fájlba irása
                writer.println("\nKategória [" + (i+1) + "]:");
                writer.println("  ID: " + id);
                writer.println("  Megnevezés: " + megnevezes);
                writer.println("  Leírás: " + leiras);
            }
        }
    }

    /*
     ez a metódus kiolvassa és kiírja a könyvek adatait a dokumentumból.
     */
    private static void readAndPrintKonyvData(Document document, PrintWriter writer) {
        //könyv elemek lekérdezése
        NodeList konyvList = document.getElementsByTagName("konyv");

        //információ a találatok számáról
        String countInfo = "Összesen " + konyvList.getLength() + " könyv található.";
        System.out.println(countInfo);
        writer.println(countInfo);

        //végigmegyünk minden könyv elemen
        for (int i = 0; i < konyvList.getLength(); i++) {
            Node konyvNode = konyvList.item(i);

            //ellenőrizzük, hogy elem típusú-e a csomópont (node)
            if (konyvNode.getNodeType() == Node.ELEMENT_NODE) {
                Element konyvElement = (Element) konyvNode;

                //könyv ID attribútum
                String id = konyvElement.getAttribute("id");

                //adatok kinyerése az elemekből
                String cim = getElementTextContent(konyvElement, "cim");
                String szerzo = getElementTextContent(konyvElement, "szerzo");
                String kiado = getElementTextContent(konyvElement, "kiado");
                String ev = getElementTextContent(konyvElement, "ev");
                String kategoriaRef = getElementTextContent(konyvElement, "kategoriaRef");

                //adatok kiírása
                System.out.println("\nKönyv [" + (i+1) + "]:");
                System.out.println("  ID: " + id);
                System.out.println("  Cím: " + cim);
                System.out.println("  Szerző: " + szerzo);
                System.out.println("  Kiadó: " + kiado);
                System.out.println("  Kiadás éve: " + ev);
                System.out.println("  Kategória hivatkozás: " + kategoriaRef);

                //adatok fájlba irása
                writer.println("\nKönyv [" + (i+1) + "]:");
                writer.println("  ID: " + id);
                writer.println("  Cím: " + cim);
                writer.println("  Szerző: " + szerzo);
                writer.println("  Kiadó: " + kiado);
                writer.println("  Kiadás éve: " + ev);
                writer.println("  Kategória hivatkozás: " + kategoriaRef);
            }
        }
    }

    /*
     ez a metódus kiolvassa és kiírja a részlegek adatait a dokumentumból.
     */
    private static void readAndPrintReszlegData(Document document, PrintWriter writer) {
        //részleg elemek lekérdezése
        NodeList reszlegList = document.getElementsByTagName("reszleg");

        //információ a találatok számáról
        String countInfo = "Összesen " + reszlegList.getLength() + " részleg található.";
        System.out.println(countInfo);
        writer.println(countInfo);

        //végigmegyünk minden részleg elemen
        for (int i = 0; i < reszlegList.getLength(); i++) {
            Node reszlegNode = reszlegList.item(i);

            //ellenőrizzük, hogy elem típusú-e a csomópont (node)
            if (reszlegNode.getNodeType() == Node.ELEMENT_NODE) {
                Element reszlegElement = (Element) reszlegNode;

                //részleg ID attribútum
                String id = reszlegElement.getAttribute("id");

                //adatok kinyerése az elemekből
                String nev = getElementTextContent(reszlegElement, "nev");
                String emelet = getElementTextContent(reszlegElement, "emelet");
                String nyitvatartas = getElementTextContent(reszlegElement, "nyitvatartas");
                String konyvtarosRef = getElementTextContent(reszlegElement, "konyvtarosRef");

                //adatok kiírása
                System.out.println("\nRészleg [" + (i+1) + "]:");
                System.out.println("  ID: " + id);
                System.out.println("  Név: " + nev);
                System.out.println("  Emelet: " + emelet);
                System.out.println("  Nyitvatartás: " + nyitvatartas);
                System.out.println("  Könyvtáros hivatkozás: " + konyvtarosRef);

                //adatok fájlba irása
                writer.println("\nRészleg [" + (i+1) + "]:");
                writer.println("  ID: " + id);
                writer.println("  Név: " + nev);
                writer.println("  Emelet: " + emelet);
                writer.println("  Nyitvatartás: " + nyitvatartas);
                writer.println("  Könyvtáros hivatkozás: " + konyvtarosRef);
            }
        }
    }

    /*
     ez a metódus kiolvassa és kiírja a könyvtárosok adatait a dokumentumból.
     */
    private static void readAndPrintKonyvtarosData(Document document, PrintWriter writer) {
        //könyvtáros elemek lekérdezése
        NodeList konyvtarosList = document.getElementsByTagName("konyvtaros");

        //információ a találatok számáról
        String countInfo = "Összesen " + konyvtarosList.getLength() + " könyvtáros található.";
        System.out.println(countInfo);
        writer.println(countInfo);

        //végigmegyünk minden könyvtáros elemen
        for (int i = 0; i < konyvtarosList.getLength(); i++) {
            Node konyvtarosNode = konyvtarosList.item(i);

            // ellenőrizzük, hogy elem típusú-e a csomópont (node)
            if (konyvtarosNode.getNodeType() == Node.ELEMENT_NODE) {
                Element konyvtarosElement = (Element) konyvtarosNode;

                //könyvtáros ID attribútum
                String id = konyvtarosElement.getAttribute("id");

                //adatok kinyerése az elemekből
                String nev = getElementTextContent(konyvtarosElement, "nev");
                String telefon = getElementTextContent(konyvtarosElement, "telefon");
                String email = getElementTextContent(konyvtarosElement, "email");
                String beosztas = getElementTextContent(konyvtarosElement, "beosztas");
                String reszlegRef = getElementTextContent(konyvtarosElement, "reszlegRef");

                //adatok kiírása
                System.out.println("\nKönyvtáros [" + (i+1) + "]:");
                System.out.println("  ID: " + id);
                System.out.println("  Név: " + nev);
                System.out.println("  Telefon: " + telefon);
                System.out.println("  Email: " + email);
                System.out.println("  Beosztás: " + beosztas);
                System.out.println("  Részleg hivatkozás: " + reszlegRef);

                //adatok fájlba irása
                writer.println("\nKönyvtáros [" + (i+1) + "]:");
                writer.println("  ID: " + id);
                writer.println("  Név: " + nev);
                writer.println("  Telefon: " + telefon);
                writer.println("  Email: " + email);
                writer.println("  Beosztás: " + beosztas);
                writer.println("  Részleg hivatkozás: " + reszlegRef);
            }
        }
    }

    /*
     ez a metódus kiolvassa és kiírja a kölcsönzések adatait a dokumentumból.
     */
    private static void readAndPrintKolcsonzesData(Document document, PrintWriter writer) {
        //kölcsönzés elemek lekérdezése
        NodeList kolcsonzesList = document.getElementsByTagName("kolcsonzes");

        //információ a találatok számáról
        String countInfo = "Összesen " + kolcsonzesList.getLength() + " kölcsönzés található.";
        System.out.println(countInfo);
        writer.println(countInfo);

        //végigmegyünk minden kölcsönzés elemen
        for (int i = 0; i < kolcsonzesList.getLength(); i++) {
            Node kolcsonzesNode = kolcsonzesList.item(i);

            //ellenőrizzük, hogy elem típusú-e a csomópont (node)
            if (kolcsonzesNode.getNodeType() == Node.ELEMENT_NODE) {
                Element kolcsonzesElement = (Element) kolcsonzesNode;

                //kölcsönzés ID attribútum
                String id = kolcsonzesElement.getAttribute("id");

                //adatok kinyerése az elemekből
                String datum = getElementTextContent(kolcsonzesElement, "datum");
                String hatarido = getElementTextContent(kolcsonzesElement, "hatarido");
                String diakRef = getElementTextContent(kolcsonzesElement, "diakRef");
                String konyvtarosRef = getElementTextContent(kolcsonzesElement, "konyvtarosRef");

                //adatok kiírása
                System.out.println("\nKölcsönzés [" + (i+1) + "]:");
                System.out.println("  ID: " + id);
                System.out.println("  Dátum: " + datum);
                System.out.println("  Határidő: " + hatarido);
                System.out.println("  Diák hivatkozás: " + diakRef);
                System.out.println("  Könyvtáros hivatkozás: " + konyvtarosRef);

                //adatok fájlba irása
                writer.println("\nKölcsönzés [" + (i+1) + "]:");
                writer.println("  ID: " + id);
                writer.println("  Dátum: " + datum);
                writer.println("  Határidő: " + hatarido);
                writer.println("  Diák hivatkozás: " + diakRef);
                writer.println("  Könyvtáros hivatkozás: " + konyvtarosRef);

                // a kölcsönzött könyvek információinak kinyerése
                NodeList kolcsonzottKonyvList = kolcsonzesElement.getElementsByTagName("kolcsonzottKonyv");
                System.out.println("  Kölcsönzött könyvek (" + kolcsonzottKonyvList.getLength() + " db):");
                writer.println("  Kölcsönzött könyvek (" + kolcsonzottKonyvList.getLength() + " db):");

                //végigmegyünk minden kölcsönzött könyvön és kinyerjük az adatokat
                for (int j = 0; j < kolcsonzottKonyvList.getLength(); j++) {
                    Element kolcsonzottKonyvElement = (Element) kolcsonzottKonyvList.item(j);

                    String konyvRef = getElementTextContent(kolcsonzottKonyvElement, "konyvRef");
                    String visszahozasiAllapot = getElementTextContent(kolcsonzottKonyvElement, "visszahozasiAllapot");
                    String megjegyzes = getElementTextContent(kolcsonzottKonyvElement, "megjegyzes");
                    String tenylegesVisszahozasDatuma = getElementTextContent(kolcsonzottKonyvElement, "tenylegesVisszahozasDatuma");
                    String hosszabbitasokSzama = getElementTextContent(kolcsonzottKonyvElement, "hosszabbitasokSzama");

                    //adatok kiírása
                    System.out.println("    - Könyv hivatkozás: " + konyvRef);
                    System.out.println("      Visszahozási állapot: " + visszahozasiAllapot);
                    System.out.println("      Megjegyzés: " + (megjegyzes.isEmpty() ? "[nincs megjegyzés]" : megjegyzes));
                    System.out.println("      Tényleges visszahozás dátuma: " + tenylegesVisszahozasDatuma);
                    System.out.println("      Hosszabbítások száma: " + hosszabbitasokSzama);

                    //adatok fájlba irása
                    writer.println("    - Könyv hivatkozás: " + konyvRef);
                    writer.println("      Visszahozási állapot: " + visszahozasiAllapot);
                    writer.println("      Megjegyzés: " + (megjegyzes.isEmpty() ? "[nincs megjegyzés]" : megjegyzes));
                    writer.println("      Tényleges visszahozás dátuma: " + tenylegesVisszahozasDatuma);
                    writer.println("      Hosszabbítások száma: " + hosszabbitasokSzama);
                }
            }
        }
    }

    /*
     ez a metódus egy segédfüggvény, amely egy elem adott gyerek elemének szöveges tartalmát adja vissza.
     ha nem létezik gyerekelem akkor üres stringet ad vissza
     */
    private static String getElementTextContent(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        if (nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        } else {
            return "";
        }
    }
}